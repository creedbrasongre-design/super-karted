NEON DRIFT — COMPRESSED GITHUB ACTIONS PUBLISHING

1. Replace the repository's current index.html with the index.html in this package.
2. Replace the contents of .github/workflows/publish-neon-drift-scenery.yml with the included workflow file.
3. Wait for GitHub Pages to finish deploying.
4. Open the live game at the same GitHub Pages URL and enter the 3D Course Scenery Studio.
5. Your saved draft should still be there because the URL/browser storage did not change.
6. Select the course, press EXPORT, and copy the new code beginning with NDCS3.
7. In GitHub: Actions > Publish Neon Drift Scenery > Run workflow.
8. Paste the NDCS3 code and run the workflow.

NDCS3 compresses the scenery and stores repeated voxel models only once, which avoids the manual Actions input size problem for normal course designs.
